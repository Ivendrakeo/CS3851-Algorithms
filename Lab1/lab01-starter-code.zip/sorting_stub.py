def insertion_sort(lst):
    """
    Sorts the list lst in place using insertion_sort.
    """
